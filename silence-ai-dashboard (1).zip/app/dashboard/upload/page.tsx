"use client"

import { useState } from "react"
import {
  Upload,
  Mic,
  FileAudio,
  Play,
  X,
  Brain,
  CheckCircle,
  Loader2,
  MessageSquare,
  Smile,
} from "lucide-react"

type UploadState = "idle" | "recording" | "uploaded" | "analyzing" | "complete"

const moodOptions = [
  { label: "Great", value: "great", color: "bg-primary/10 text-primary border-primary/20" },
  { label: "Good", value: "good", color: "bg-chart-2/10 text-chart-2 border-chart-2/20" },
  { label: "Okay", value: "okay", color: "bg-chart-3/10 text-chart-3 border-chart-3/20" },
  { label: "Low", value: "low", color: "bg-chart-4/10 text-chart-4 border-chart-4/20" },
  { label: "Very Low", value: "very-low", color: "bg-destructive/10 text-destructive border-destructive/20" },
]

export default function VoiceUploadPage() {
  const [state, setState] = useState<UploadState>("idle")
  const [selectedFile, setSelectedFile] = useState<string | null>(null)
  const [mood, setMood] = useState<string | null>(null)
  const [journalEntry, setJournalEntry] = useState("")
  const [recordingTime, setRecordingTime] = useState(0)

  function handleFileSelect() {
    setSelectedFile("voice_note_2026_02_12.wav")
    setState("uploaded")
  }

  function handleRecord() {
    if (state === "recording") {
      setState("uploaded")
      setSelectedFile(`recording_${recordingTime}s.wav`)
      return
    }
    setState("recording")
    setRecordingTime(0)
    const interval = setInterval(() => {
      setRecordingTime((prev) => prev + 1)
    }, 1000)
    setTimeout(() => {
      clearInterval(interval)
      setState("uploaded")
      setSelectedFile("recording_15s.wav")
    }, 15000)
    return () => clearInterval(interval)
  }

  function handleAnalyze() {
    setState("analyzing")
    setTimeout(() => setState("complete"), 3000)
  }

  return (
    <div className="flex flex-col gap-6 p-4 md:p-6">
      <div className="flex flex-col gap-1">
        <h2 className="text-lg font-bold text-foreground">Data Input</h2>
        <p className="text-sm text-muted-foreground">
          Submit voice notes, mood logs, and journal entries for AI analysis.
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Voice Upload / Record Section */}
        <div className="flex flex-col gap-5 rounded-2xl border border-border bg-card/60 p-6 backdrop-blur-md">
          <div className="flex items-center gap-2">
            <FileAudio className="h-4 w-4 text-primary" />
            <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">
              Voice Note
            </h3>
          </div>

          {/* Record Button */}
          <div className="flex flex-col items-center gap-4 py-4">
            <button
              onClick={handleRecord}
              className={`flex h-24 w-24 items-center justify-center rounded-full border-2 transition-all ${
                state === "recording"
                  ? "animate-pulse border-destructive bg-destructive/10"
                  : "border-primary/30 bg-primary/5 hover:bg-primary/10"
              }`}
              aria-label={state === "recording" ? "Stop recording" : "Start recording"}
            >
              {state === "recording" ? (
                <div className="flex flex-col items-center gap-1">
                  <div className="h-6 w-6 rounded-sm bg-destructive" />
                  <span className="font-mono text-[10px] text-destructive">{recordingTime}s</span>
                </div>
              ) : (
                <Mic className="h-8 w-8 text-primary" />
              )}
            </button>
            <p className="text-xs text-muted-foreground">
              {state === "recording" ? "Recording... tap to stop" : "Tap to record a voice note"}
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="h-px flex-1 bg-border" />
            <span className="text-xs text-muted-foreground">or</span>
            <div className="h-px flex-1 bg-border" />
          </div>

          {/* File Upload */}
          <button
            onClick={handleFileSelect}
            className="flex flex-col items-center gap-3 rounded-xl border-2 border-dashed border-border bg-secondary/30 p-8 transition-colors hover:border-primary/30 hover:bg-secondary/50"
          >
            <Upload className="h-8 w-8 text-muted-foreground" />
            <div className="text-center">
              <p className="text-sm font-medium text-foreground">Upload audio file</p>
              <p className="text-xs text-muted-foreground">.wav, .mp3, .ogg supported</p>
            </div>
          </button>

          {/* Selected File */}
          {selectedFile && (
            <div className="flex items-center gap-3 rounded-xl border border-primary/20 bg-primary/5 p-3">
              <Play className="h-4 w-4 text-primary" />
              <span className="flex-1 text-sm text-foreground">{selectedFile}</span>
              <button
                onClick={() => {
                  setSelectedFile(null)
                  setState("idle")
                }}
                className="text-muted-foreground hover:text-foreground"
                aria-label="Remove file"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          )}

          {/* Analyze Button */}
          {(state === "uploaded" || state === "complete") && (
            <button
              onClick={handleAnalyze}
              disabled={state === "analyzing"}
              className="flex items-center justify-center gap-2 rounded-xl bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90 disabled:opacity-50"
            >
              {state === "analyzing" ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" /> Analyzing...
                </>
              ) : state === "complete" ? (
                <>
                  <CheckCircle className="h-4 w-4" /> Analysis Complete
                </>
              ) : (
                <>
                  <Brain className="h-4 w-4" /> Analyze with AI
                </>
              )}
            </button>
          )}

          {/* Analysis Result */}
          {state === "complete" && (
            <div className="flex flex-col gap-3 rounded-xl border border-primary/20 bg-primary/5 p-4">
              <h4 className="text-sm font-semibold text-foreground">AI Analysis Result</h4>
              <div className="grid grid-cols-3 gap-3">
                <div className="rounded-lg bg-secondary/60 p-2 text-center">
                  <p className="font-mono text-base font-bold text-primary">1.6s</p>
                  <p className="text-[9px] text-muted-foreground">Avg Pause</p>
                </div>
                <div className="rounded-lg bg-secondary/60 p-2 text-center">
                  <p className="font-mono text-base font-bold text-chart-3">42</p>
                  <p className="text-[9px] text-muted-foreground">Risk Score</p>
                </div>
                <div className="rounded-lg bg-secondary/60 p-2 text-center">
                  <p className="font-mono text-base font-bold text-chart-2">6</p>
                  <p className="text-[9px] text-muted-foreground">Patterns</p>
                </div>
              </div>
              <p className="text-xs leading-relaxed text-muted-foreground">
                Moderate hesitation detected with 6 significant pauses. Voice energy showed a
                declining pattern in the final third of the recording. Recommend follow-up in
                24-48 hours.
              </p>
            </div>
          )}
        </div>

        {/* Right Column: Mood + Journal */}
        <div className="flex flex-col gap-6">
          {/* Mood Selector */}
          <div className="flex flex-col gap-4 rounded-2xl border border-border bg-card/60 p-6 backdrop-blur-md">
            <div className="flex items-center gap-2">
              <Smile className="h-4 w-4 text-chart-3" />
              <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">
                Daily Mood Log
              </h3>
            </div>
            <p className="text-xs text-muted-foreground">How are you feeling right now?</p>
            <div className="flex flex-wrap gap-2">
              {moodOptions.map((option) => (
                <button
                  key={option.value}
                  onClick={() => setMood(option.value)}
                  className={`rounded-lg border px-4 py-2 text-sm font-medium transition-all ${
                    mood === option.value
                      ? `${option.color} ring-1 ring-current`
                      : "border-border bg-secondary/30 text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {option.label}
                </button>
              ))}
            </div>
            {mood && (
              <p className="text-xs text-primary">
                Mood logged. This data helps AI track emotional trends over time.
              </p>
            )}
          </div>

          {/* Journal Entry */}
          <div className="flex flex-1 flex-col gap-4 rounded-2xl border border-border bg-card/60 p-6 backdrop-blur-md">
            <div className="flex items-center gap-2">
              <MessageSquare className="h-4 w-4 text-chart-2" />
              <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">
                Journal Entry
              </h3>
            </div>
            <p className="text-xs text-muted-foreground">
              Write about your day. AI will analyze patterns in your writing over time.
            </p>
            <textarea
              value={journalEntry}
              onChange={(e) => setJournalEntry(e.target.value)}
              placeholder="How was your day? What's on your mind..."
              className="flex-1 resize-none rounded-xl border border-border bg-secondary/30 p-4 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary/50 focus:outline-none focus:ring-1 focus:ring-primary/30"
              rows={6}
            />
            <div className="flex items-center justify-between">
              <span className="text-[10px] text-muted-foreground">
                {journalEntry.length} characters
              </span>
              <button
                disabled={!journalEntry.trim()}
                className="rounded-lg bg-primary px-5 py-2 text-xs font-semibold text-primary-foreground transition-colors hover:bg-primary/90 disabled:opacity-40"
              >
                Save Entry
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
