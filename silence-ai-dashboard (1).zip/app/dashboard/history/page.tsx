"use client"

import {
  Line,
  LineChart,
  Bar,
  BarChart,
  ResponsiveContainer,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from "recharts"
import { Calendar, Clock, TrendingDown, TrendingUp, ArrowRight } from "lucide-react"
import Link from "next/link"

const riskOverTime = [
  { date: "Jan 5", score: 22 },
  { date: "Jan 12", score: 28 },
  { date: "Jan 19", score: 35 },
  { date: "Jan 26", score: 31 },
  { date: "Feb 2", score: 42 },
  { date: "Feb 5", score: 38 },
  { date: "Feb 8", score: 45 },
  { date: "Feb 10", score: 38 },
  { date: "Feb 11", score: 41 },
  { date: "Feb 12", score: 36 },
]

const pauseTrends = [
  { week: "W1", avgPause: 0.8 },
  { week: "W2", avgPause: 1.1 },
  { week: "W3", avgPause: 1.4 },
  { week: "W4", avgPause: 1.2 },
  { week: "W5", avgPause: 1.8 },
  { week: "W6", avgPause: 1.5 },
  { week: "W7", avgPause: 2.0 },
  { week: "W8", avgPause: 1.6 },
]

const sessions = [
  {
    id: 1,
    date: "Feb 12, 2026",
    time: "2:34 PM",
    duration: "14:32",
    riskLevel: "Medium" as const,
    riskScore: 38,
    patterns: 23,
    silencePercent: 23,
  },
  {
    id: 2,
    date: "Feb 11, 2026",
    time: "10:15 AM",
    duration: "8:47",
    riskLevel: "Low" as const,
    riskScore: 22,
    patterns: 11,
    silencePercent: 14,
  },
  {
    id: 3,
    date: "Feb 10, 2026",
    time: "4:02 PM",
    duration: "21:15",
    riskLevel: "High" as const,
    riskScore: 67,
    patterns: 41,
    silencePercent: 38,
  },
  {
    id: 4,
    date: "Feb 9, 2026",
    time: "11:30 AM",
    duration: "12:08",
    riskLevel: "Low" as const,
    riskScore: 19,
    patterns: 8,
    silencePercent: 11,
  },
  {
    id: 5,
    date: "Feb 8, 2026",
    time: "3:45 PM",
    duration: "16:22",
    riskLevel: "Medium" as const,
    riskScore: 45,
    patterns: 28,
    silencePercent: 27,
  },
  {
    id: 6,
    date: "Feb 7, 2026",
    time: "9:10 AM",
    duration: "6:55",
    riskLevel: "Low" as const,
    riskScore: 15,
    patterns: 5,
    silencePercent: 8,
  },
]

const riskColors = {
  Low: { bg: "bg-primary/10", text: "text-primary", border: "border-primary/20" },
  Medium: { bg: "bg-chart-3/10", text: "text-chart-3", border: "border-chart-3/20" },
  High: { bg: "bg-chart-4/10", text: "text-chart-4", border: "border-chart-4/20" },
}

const emotionalTrend = [
  { day: "Mon", mood: 72 },
  { day: "Tue", mood: 65 },
  { day: "Wed", mood: 58 },
  { day: "Thu", mood: 62 },
  { day: "Fri", mood: 45 },
  { day: "Sat", mood: 55 },
  { day: "Sun", mood: 60 },
]

const tooltipStyle = {
  backgroundColor: "hsl(220, 20%, 9%)",
  border: "1px solid hsl(220, 16%, 16%)",
  borderRadius: "8px",
  fontSize: "12px",
  color: "hsl(210, 40%, 95%)",
}

export default function HistoryPage() {
  return (
    <div className="flex flex-col gap-6 p-4 md:p-6">
      <div className="flex items-center justify-between">
        <div className="flex flex-col gap-1">
          <h2 className="text-lg font-bold text-foreground">History & Analytics</h2>
          <p className="text-sm text-muted-foreground">Track behavioral trends and past sessions.</p>
        </div>
        <Link
          href="/dashboard/insights"
          className="flex items-center gap-1 text-xs font-medium text-primary transition-colors hover:text-primary/80"
        >
          View Insights <ArrowRight className="h-3 w-3" />
        </Link>
      </div>

      {/* Charts Row */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* Risk Score Over Time */}
        <div className="flex flex-col gap-4 rounded-2xl border border-border bg-card/60 p-6 backdrop-blur-md">
          <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">
            Risk Score Over Time
          </h3>
          <div className="h-52">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={riskOverTime}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(220, 16%, 14%)" />
                <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: "hsl(215, 20%, 55%)" }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: "hsl(215, 20%, 55%)" }} domain={[0, 100]} width={30} />
                <Tooltip contentStyle={tooltipStyle} />
                <Line
                  type="monotone"
                  dataKey="score"
                  stroke="hsl(174, 72%, 52%)"
                  strokeWidth={2.5}
                  dot={{ fill: "hsl(174, 72%, 52%)", strokeWidth: 0, r: 4 }}
                  activeDot={{ r: 6, stroke: "hsl(174, 72%, 52%)", strokeWidth: 2, fill: "hsl(220, 20%, 9%)" }}
                  name="Risk Score"
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Pause Duration Trends */}
        <div className="flex flex-col gap-4 rounded-2xl border border-border bg-card/60 p-6 backdrop-blur-md">
          <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">
            Pause Duration Trends
          </h3>
          <div className="h-52">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={pauseTrends}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(220, 16%, 14%)" />
                <XAxis dataKey="week" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: "hsl(215, 20%, 55%)" }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: "hsl(215, 20%, 55%)" }} width={30} />
                <Tooltip contentStyle={tooltipStyle} />
                <Bar dataKey="avgPause" fill="hsl(199, 89%, 48%)" radius={[4, 4, 0, 0]} name="Avg Pause (s)" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Emotional Trend */}
      <div className="flex flex-col gap-4 rounded-2xl border border-border bg-card/60 p-6 backdrop-blur-md">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">
            Emotional Trend (This Week)
          </h3>
          <div className="flex items-center gap-1 text-xs text-chart-4">
            <TrendingDown className="h-3.5 w-3.5" />
            <span>Declining</span>
          </div>
        </div>
        <div className="h-40">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={emotionalTrend}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(220, 16%, 14%)" />
              <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: "hsl(215, 20%, 55%)" }} />
              <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: "hsl(215, 20%, 55%)" }} domain={[0, 100]} width={30} />
              <Tooltip contentStyle={tooltipStyle} />
              <Line
                type="monotone"
                dataKey="mood"
                stroke="hsl(45, 93%, 58%)"
                strokeWidth={2.5}
                dot={{ fill: "hsl(45, 93%, 58%)", strokeWidth: 0, r: 4 }}
                name="Mood Score"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Session List */}
      <div className="flex flex-col gap-4 rounded-2xl border border-border bg-card/60 p-6 backdrop-blur-md">
        <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">
          Recent Sessions
        </h3>
        <div className="flex flex-col gap-3">
          {sessions.map((session) => {
            const style = riskColors[session.riskLevel]
            return (
              <div
                key={session.id}
                className={`flex flex-col gap-3 rounded-xl border ${style.border} ${style.bg} p-4 sm:flex-row sm:items-center sm:justify-between`}
              >
                <div className="flex items-center gap-4">
                  <div className="flex flex-col items-center gap-0.5">
                    <Calendar className="h-3.5 w-3.5 text-muted-foreground" />
                    <span className="text-[10px] text-muted-foreground">{session.date}</span>
                  </div>
                  <div className="flex flex-col gap-0.5">
                    <span className="text-sm font-medium text-foreground">
                      Session at {session.time}
                    </span>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Clock className="h-3 w-3" />
                      {session.duration} min
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-center">
                    <p className={`font-mono text-sm font-bold ${style.text}`}>{session.riskScore}</p>
                    <p className="text-[9px] text-muted-foreground">Risk</p>
                  </div>
                  <div className="text-center">
                    <p className="font-mono text-sm font-bold text-foreground">{session.patterns}</p>
                    <p className="text-[9px] text-muted-foreground">Patterns</p>
                  </div>
                  <div className="text-center">
                    <p className="font-mono text-sm font-bold text-foreground">{session.silencePercent}%</p>
                    <p className="text-[9px] text-muted-foreground">Silence</p>
                  </div>
                  <span className={`rounded-full px-3 py-1 text-[10px] font-bold ${style.bg} ${style.text}`}>
                    {session.riskLevel}
                  </span>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
